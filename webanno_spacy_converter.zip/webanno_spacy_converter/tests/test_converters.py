from ..converters.spacy_to_webanno import DocBinToAnnotationSentencesConverter
from ..writers.webanno_writer import WebAnnoNELWriter
import os
import spacy

nlp = spacy.load("my_nlp_el_cnn1")
converter = DocBinToAnnotationSentencesConverter(nlp)
#get all .spacy files in the root directory

spacy_files = [f for f in os.listdir(".") if f.endswith(".spacy")]

for spacy_file in spacy_files:
    
    # Convert the DocBin object to AnnotationSentence objects
    sentences = converter.convert(spacy_file)
    
    # Create an output filename based on the input filename
    output_filename = os.path.splitext(spacy_file)[0] + ".tsv"
    
    # Write the sentences to a WebAnno TSV file
    writer = WebAnnoNELWriter(sentences)
    writer.save(output_filename)
    print(f"Converted {spacy_file} to {output_filename}")





